/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import codigo.RS.RS;
import java.util.ArrayList;

/**
 *
 * @author jeanp
 */
public class PS {
    public ArrayList<RS> pila;
}
