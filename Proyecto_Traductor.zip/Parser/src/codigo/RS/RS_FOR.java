/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo.RS;

/**
 *
 * @author jeanp
 */
public class RS_FOR extends RS{
    public String labelFor;
    public String labelExit;

    public RS_FOR(String token, String labelFor, String labelExit) {
        this.token = token;
        this.labelFor = labelFor;
        this.labelExit = labelExit;
    }
    
}
