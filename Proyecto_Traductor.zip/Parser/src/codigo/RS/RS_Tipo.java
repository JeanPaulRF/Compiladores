/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo.RS;

/**
 *
 * @author jeanp
 */
public class RS_Tipo extends RS{
    public String tipo;

    public RS_Tipo(String token, String tipo) {
        this.token = token;
        this.tipo = tipo;
    } 
}
