/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo.RS;

/**
 *
 * @author jeanp
 */
public class RS_Funcion extends RS{
    public String nombre;

    public RS_Funcion(String token, String nombre) {
        this.token = token;
        this.nombre = nombre;
    }
    
}
